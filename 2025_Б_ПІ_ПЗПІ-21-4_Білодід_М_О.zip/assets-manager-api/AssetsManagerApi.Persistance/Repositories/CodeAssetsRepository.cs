﻿using AssetsManagerApi.Application.IRepositories;
using AssetsManagerApi.Domain.Entities;
using AssetsManagerApi.Persistance.Db;
using Microsoft.Azure.Cosmos;

namespace AssetsManagerApi.Persistance.Repositories;

public class CodeAssetsRepository(CosmosDbContext db)
    : BaseRepository<CodeAsset>(db, "CodeAssets"), ICodeAssetsRepository
{
    //public async Task<List<CodeAsset>> VectorSearchAsync(float[] queryVector, int topN, CancellationToken cancellationToken)
    //{
    //    string query = $@"
    //    SELECT TOP {topN} c.*, VECTOR_COSINE(c.Vector, @queryVector) AS similarity
    //    FROM c
    //    WHERE IS_DEFINED(c.Vector)
    //    ORDER BY similarity DESC
    //";

    //    var queryDefinition = new QueryDefinition(query)
    //        .WithParameter("@queryVector", queryVector);

    //    var results = new List<CodeAsset>();
    //    using var feedIterator = _container.GetItemQueryIterator<CodeAsset>(queryDefinition);

    //    while (feedIterator.HasMoreResults)
    //    {
    //        foreach (var item in await feedIterator.ReadNextAsync(cancellationToken))
    //        {
    //            results.Add(item);
    //        }
    //    }

    //    return results;
    //}
}
