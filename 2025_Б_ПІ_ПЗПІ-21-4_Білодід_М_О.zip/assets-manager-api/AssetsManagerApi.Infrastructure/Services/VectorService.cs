﻿using AssetsManagerApi.Application.IServices;
using Microsoft.Extensions.Logging;
using System.Net.Http.Json;
using System.Text.Json;

namespace AssetsManagerApi.Infrastructure.Services
{
    public class VectorService : IVectorService
    {
        private readonly ILogger<VectorService> _logger;
        private readonly HttpClient _httpClient;

        public VectorService(ILogger<VectorService> logger, HttpClient httpClient)
        {
            _logger = logger;
            _httpClient = httpClient;
        }

        public async Task<float[]> GetTextEmbeddingAsync(string text, CancellationToken cancellationToken)
        {
            _logger.LogInformation("Requesting embedding for text: {text}", text);

            var request = new
            {
                model = "text-embedding-3-small",
                input = text,
                encoding_format = "float",
            };

            var response = await _httpClient.PostAsJsonAsync("/v1/embeddings", request, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                _logger.LogError("Failed to get embedding. Status code: {statusCode}", response.StatusCode);
                throw new HttpRequestException($"Failed to get embedding. Status code: {response.StatusCode}");
            }

            var jsonResponse = await response.Content.ReadFromJsonAsync<JsonElement>(cancellationToken: cancellationToken);

            var embedding = jsonResponse
                .GetProperty("data")[0]
                .GetProperty("embedding")
                .EnumerateArray()
                .Select(x => x.GetSingle())
                .ToArray();

            _logger.LogInformation("Successfully retrieved embedding for text.");
            return embedding;
        }
    }
}
