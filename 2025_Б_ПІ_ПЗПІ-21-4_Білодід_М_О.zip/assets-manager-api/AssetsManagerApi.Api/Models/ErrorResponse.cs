namespace AssetsManagerApi.Api.Models;

public class ErrorResponse
{
    public string Message { get; set; }
}
