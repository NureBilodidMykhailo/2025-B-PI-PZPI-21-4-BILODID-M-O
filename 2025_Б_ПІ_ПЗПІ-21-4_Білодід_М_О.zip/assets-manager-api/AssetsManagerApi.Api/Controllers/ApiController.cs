using Microsoft.AspNetCore.Mvc;

namespace AssetsManagerApi.Api.Controllers;

[ApiController]
public class ApiController : ControllerBase
{
    
}
