﻿namespace AssetsManagerApi.Domain.Enums;

public enum AssetTypes
{
    Public = 1, 
    Corporate = 2,
    StartProject = 3
}
