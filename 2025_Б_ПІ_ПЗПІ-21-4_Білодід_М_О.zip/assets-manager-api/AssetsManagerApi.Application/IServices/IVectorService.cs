﻿namespace AssetsManagerApi.Application.IServices
{
    public interface IVectorService
    {
        Task<float[]> GetTextEmbeddingAsync(string text, CancellationToken cancellationToken);
    }
}
