namespace AssetsManagerApi.Application.Models.Identity;

public class Login
{
    public string? Phone { get; set; }

    public string? Email { get; set; }

    public string? Password { get; set; }
}
