﻿namespace AssetsManagerApi.Application.Models.Dto;

public class RoleDto
{
    public string Id { get; set; }

    public string Name { get; set; }
}
