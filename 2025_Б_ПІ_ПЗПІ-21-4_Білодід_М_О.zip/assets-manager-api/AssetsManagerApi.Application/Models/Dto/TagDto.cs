﻿namespace AssetsManagerApi.Application.Models.Dto;

public class TagDto
{
    public string Id { get; set; }

    public string Name { get; set; }
}
