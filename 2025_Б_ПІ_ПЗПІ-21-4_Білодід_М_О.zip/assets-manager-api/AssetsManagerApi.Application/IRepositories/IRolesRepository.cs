using AssetsManagerApi.Domain.Entities.Identity;

namespace AssetsManagerApi.Application.IRepositories;

public interface IRolesRepository : IBaseRepository<Role>
{
    
}
