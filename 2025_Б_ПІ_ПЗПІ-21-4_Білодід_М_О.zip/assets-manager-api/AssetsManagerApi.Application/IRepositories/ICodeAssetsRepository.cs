﻿using AssetsManagerApi.Domain.Entities;

namespace AssetsManagerApi.Application.IRepositories;

public interface ICodeAssetsRepository : IBaseRepository<CodeAsset>
{
}
