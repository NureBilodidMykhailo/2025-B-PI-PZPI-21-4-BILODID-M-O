using AssetsManagerApi.Domain.Entities.Identity;

namespace AssetsManagerApi.Application.IRepositories;

public interface IRefreshTokensRepository : IBaseRepository<RefreshToken>
{
    
}
